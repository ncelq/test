require('@alipay/appx-compiler/lib/sjsEnvInit');
require('./config$');

require('../../node_modules/mini-antui/es/grid/index');
require('../../node_modules/mini-antui/es/card/index');
require('../../pages/index/index');
require('../../pages/login/login');

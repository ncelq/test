Page({
  data: {

  },
  onLoad() {
  },
  onSubmit() {
    my.request({
      url: 'https://openlab.openbankproject.com/my/logins/direct',
      method: 'POST',
      dataType: 'json',
      headers: {
        'Authorization': 'DirectLogin username="Robert.Hk.01",password="X!b3726b93",consumer_key="csacktdpktl3ay3uiatxu43jb3jbx2x3ohuls1zn"'
      },
      success: function(res) {
        //my.alert({content: JSON.stringify(res.data.token)});
        console.info(res.data.token);

        my.request({
          url: 'https://openlab.openbankproject.com/obp/v3.1.0/banks/hsbc.01.hk.hsbc/balances',
          method: 'GET',
          dataType: 'json',
          headers: {
            'Authorization': 'DirectLogin token="'+res.data.token+'"'
          },
          success: function(res) {
            my.alert({content: JSON.stringify(res.data)});
            console.info(res.data);
          },
          fail: function(res) {
            my.alert({content: JSON.stringify(res)});
          },

        });
        
      },
      fail: function(res) {
        my.alert({content: JSON.stringify(res)});
      },
      complete: function(res) {
        //my.alert({title: 'complete'});
        //my.alert({content: JSON.stringify(res)});
      }
    });
  },
});

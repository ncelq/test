Page({
  data: {
    background: ['hk', 'hk2'],
    indicatorDots: true,
    autoplay: true,
    vertical: false,
    interval: 5000,
    circular: true,
    list1: [
      {
        icon: '/image/icon/icon1.jpg',
        text: '账户查询',
      },
      {
        icon: '/image/icon/icon2.jpg',
        text: '转账',
      },
      {
        icon: '/image/icon/icon3.jpg',
        text: '外汇服务',
      },
      {
        icon: '/image/icon/icon4.jpg',
        text: '我的积分',
      },
    ],

  },
  onItemClick(ev) {
    if (ev.detail.index=='') {
      my.navigateTo({
        url: '/pages/login/login',
      });
    }
  },
  onCardClick: function(ev) {
     my.alert({
      content: ev.detail.index,
    });
  },
  onLoad() {
  }
});
